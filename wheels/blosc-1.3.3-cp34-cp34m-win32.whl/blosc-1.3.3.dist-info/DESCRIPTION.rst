
Blosc is a high performance compressor optimized for binary data.



